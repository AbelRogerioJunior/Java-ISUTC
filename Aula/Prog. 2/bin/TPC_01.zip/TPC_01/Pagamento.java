package TPC_01;

interface Pagamento{


    //Calcular Salario
    public double calcularPagamento();
}